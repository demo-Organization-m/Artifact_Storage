# Fast_API
Create the fastapi
